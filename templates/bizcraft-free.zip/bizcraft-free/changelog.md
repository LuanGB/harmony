## Version 1.0.0 (4 aug 2019)
- Initial template
- Bootstrap version 3.0.0

## Version 2.0.0 (25 aug 2019)
- Bootstrap version 4.3.1